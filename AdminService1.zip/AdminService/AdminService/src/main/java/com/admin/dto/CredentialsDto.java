package com.admin.dto;

public record CredentialsDto (String email, char[] password) { }