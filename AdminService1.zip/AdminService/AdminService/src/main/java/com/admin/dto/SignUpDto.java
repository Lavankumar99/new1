package com.admin.dto;

public record SignUpDto (String fullName, String email,String address, char[] password,String mobileNumber) { }
