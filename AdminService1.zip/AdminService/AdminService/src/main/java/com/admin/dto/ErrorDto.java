package com.admin.dto;

public record ErrorDto (String message) { }
