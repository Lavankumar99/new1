import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { UserModel } from '../user-model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user=new UserModel();
  constructor(private _userservice:UserService){

  }
  registerUser(){
    this._userservice.RegisterUserfromRemote(this.user).subscribe(
      data => console.log("response recieved"),
      error=>console.log("Exception recieved")
    )
      }

}
