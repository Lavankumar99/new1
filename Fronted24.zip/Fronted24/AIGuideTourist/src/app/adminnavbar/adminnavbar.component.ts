import { Component, EventEmitter, Output } from '@angular/core';
import { Adminmodel } from '../adminmodel';


@Component({
  selector: 'app-adminnavbar',
  templateUrl: './adminnavbar.component.html',
  styleUrl: './adminnavbar.component.css'
})
export class AdminnavbarComponent {
  admin=new Adminmodel()
  @Output()  logoutEvent= new EventEmitter();

}
