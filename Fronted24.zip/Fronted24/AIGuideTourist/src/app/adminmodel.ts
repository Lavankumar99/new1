export class Adminmodel {
    email:string='';
    password:string='';

    constructor(){}
}
