package com.capgemini.dto;

public record ErrorDto (String message) { }
