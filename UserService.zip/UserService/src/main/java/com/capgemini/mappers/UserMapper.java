package com.capgemini.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.capgemini.dto.SignUpDto;
import com.capgemini.dto.UserDto;
import com.capgemini.entity.User;

@Mapper(componentModel = "spring")
public interface UserMapper {

    UserDto toUserDto(User user);

    @Mapping(target = "password", ignore = true)
    User signUpToUser(SignUpDto signUpDto);

}
