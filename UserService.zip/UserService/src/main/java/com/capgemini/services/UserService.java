package com.capgemini.services;

import java.nio.CharBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.capgemini.dto.CredentialsDto;
import com.capgemini.dto.SignUpDto;
import com.capgemini.dto.UserDto;
import com.capgemini.entity.User;
import com.capgemini.exception.AppException;
import com.capgemini.mappers.UserMapper;
import com.capgemini.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class UserService {

	
	private final UserRepository userRepo;

	private final PasswordEncoder passwordEncoder;

	private final UserMapper userMapper;
	
  

	public UserDto findUserById(Long userId) {
		Optional<User> userOptional = userRepo.findById(userId);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			UserDto userDTO = new UserDto();
			userDTO.setId(user.getId());
			userDTO.setFullName(user.getFullName());
			userDTO.setEmail(user.getEmail());
			userDTO.setMobileNumber(user.getMobileNumber());
			userDTO.setAddress(user.getAddress());
			return userDTO;
			
		} else {
			// Handle scenario when user is not found
			return null;
		}
	}

	public UserDto updateUser(Long userId, UserDto userDTO) {
		Optional<User> optionalUser = userRepo.findById(userId);
		if (optionalUser.isPresent()) {
			User existingUser = optionalUser.get();
			existingUser.setFullName(userDTO.getFullName());
			existingUser.setEmail(userDTO.getEmail());
			existingUser.setAddress(userDTO.getAddress());
			existingUser.setMobileNumber(userDTO.getMobileNumber());
			userRepo.save(existingUser);
			return userDTO;
		} else {
			// Handle scenario when user to update is not found
			return null;
		}
	}

	public List<UserDto> getAllUsers() {
		List<User> users = userRepo.findAll();
		List<UserDto> userDTOs = new ArrayList<>();

		for (User user : users) {
			UserDto userDTO = new UserDto();
			userDTO.setId(user.getId());
			userDTO.setFullName(user.getFullName());
			userDTO.setEmail(user.getEmail());
			userDTO.setMobileNumber(user.getMobileNumber());
			userDTO.setAddress(user.getAddress());
			userDTOs.add(userDTO);
		}

		return userDTOs;
	}

	public UserDto findUserByName(String userName) {
		Optional<User> userOptional = userRepo.findByFullName(userName);
		if (userOptional.isPresent()) {
			User user = userOptional.get();
			UserDto userDTO = new UserDto();
			userDTO.setId(user.getId());
			userDTO.setFullName(user.getFullName());
			userDTO.setEmail(user.getEmail());
			userDTO.setMobileNumber(user.getMobileNumber());
			userDTO.setAddress(user.getAddress());
			return userDTO;
		} else {
			// Handle scenario when user is not found
			return null;
		}
	}

	
	public Long getUserForClient(Long userId) {
		User user = userRepo.findById(userId).get();
		Long userId1 = user.getId();
		return userId1;
	}

	public UserDto login(CredentialsDto credentialsDto) {
		User user = userRepo.findByEmail(credentialsDto.email())
				.orElseThrow(() -> new AppException("Unknown user", HttpStatus.NOT_FOUND));

		if (passwordEncoder.matches(CharBuffer.wrap(credentialsDto.password()), user.getPassword())) {
			return userMapper.toUserDto(user);
		}
		throw new AppException("Invalid password", HttpStatus.BAD_REQUEST);
	}

	public UserDto register(SignUpDto userDto) {
		Optional<User> optionalUser = userRepo.findByEmail(userDto.email());

		if (optionalUser.isPresent()) {
			throw new AppException("Login already exists", HttpStatus.BAD_REQUEST);
		}

		User user = userMapper.signUpToUser(userDto);
		user.setPassword(passwordEncoder.encode(CharBuffer.wrap(userDto.password())));

		User savedUser = userRepo.save(user);

		return userMapper.toUserDto(savedUser);
	}

	public UserDto findByLoginEmail(String email) {
		User user = userRepo.findByEmail(email)
				.orElseThrow(() -> new AppException("Unknown user", HttpStatus.NOT_FOUND));
		return userMapper.toUserDto(user);
	}

	// create user
	// view user by id
	// view users
	// update user

}
